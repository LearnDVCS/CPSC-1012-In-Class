﻿using System;
using GradeBook; // to get my EvaluationComponent class
using Xunit; // for my unit testing framework

namespace GradeBook.Specs
{
    public class EvaluationComponent_Specs
    {
        [Fact] // An attribute that "decorates" my testing method
        public void Should_Create_EvaluationComponent()
        {
            // Arrange - Set up any variables/objects/expectations
            string expectedName = "Quiz 1";
            int expectedWeight = 5; // 5%

            // Act     - Do the thing I need to do/test
            EvaluationComponent itemBeingTested = new EvaluationComponent(expectedName, expectedWeight);

            // Assert  - Check that it worked right
            Assert.Equal(expectedName, itemBeingTested.Name);
            Assert.Equal(expectedWeight, itemBeingTested.Weight);
        }

        [Fact]
        public void Should_Reject_Too_Much_Weight()
        {
            // Arrange
            var name = "Quiz 1";
            var weight = 101; // <--- the value that should be too big.
            // var is a keyword that tells the compiler to figure out the
            // datatype from the value assigned to the variable

            // Act
            // A delegate here is a reference to a function
            Func<EvaluationComponent> action = delegate () 
            {   // this is my anonymous in-line function.
                // It is anoymous, because it doesn't have it's own name.
                // It is in-line, because I'm actually nesting it inside
                // of another method.
                return new EvaluationComponent(name, weight);
            };

            // Assert
            Assert.Throws<Exception>(action); // .Throws() will contain the "explosion"
        }

    }
}
