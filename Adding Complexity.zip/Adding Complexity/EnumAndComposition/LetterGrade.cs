﻿namespace EnumAndComposition
{
    public enum LetterGrade
    {
        A, B, C, D, F
    }
}
